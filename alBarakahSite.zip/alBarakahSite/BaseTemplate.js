$(document).ready(function(){
    $('.carousel').slick({
        dots: true,
        pauseOnFocus: true,
        autoplay: true,
        autoplaySpeed: 3000,
        fade: true,
        speed: 500,
        cssEase: 'linear'
    });
});